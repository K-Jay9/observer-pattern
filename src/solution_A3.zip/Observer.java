public interface Observer {
	void update(Message message);
}
